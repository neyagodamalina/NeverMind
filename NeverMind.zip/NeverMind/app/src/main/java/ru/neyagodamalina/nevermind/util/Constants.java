package ru.neyagodamalina.nevermind.util;


public interface Constants {
    public static String LOG_TAG = "NeverMind";
    public static String FRAGMENT_CREATE_TASK   = "FRAGMENT_CREATE_TASK";
    public static String FRAGMENT_LIST_TASKS    = "FRAGMENT_LIST_TASKS";
    public static String FRAGMENT_LIST_PROJECTS = "FRAGMENT_LIST_PROJECTS";
}
