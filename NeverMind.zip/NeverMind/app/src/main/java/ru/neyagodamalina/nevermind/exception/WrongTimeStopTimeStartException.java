package ru.neyagodamalina.nevermind.exception;

import android.util.Log;

import ru.neyagodamalina.nevermind.util.Constants;

/**
 * Created by developer on 28.07.2017.
 */

public class WrongTimeStopTimeStartException extends Exception {
    public WrongTimeStopTimeStartException(String message) {
        super(message);
    }
}
