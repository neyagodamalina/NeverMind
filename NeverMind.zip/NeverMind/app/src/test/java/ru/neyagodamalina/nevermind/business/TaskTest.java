package ru.neyagodamalina.nevermind.business;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by developer on 04.09.2017.
 */
public class TaskTest {
    @Test
    public void stop() throws Exception {
/*
        Task task = new Task();
        task.start();
        Thread.sleep(5000);
        task.stop();
        System.out.println(task.toString());
        task.start();
        Thread.sleep(120000);
        task.stop();
        System.out.println(task.toString());
*/

    }

}